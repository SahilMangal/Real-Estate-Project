<?php
  $connectivity = mysqli_connect("localhost", "root", "", "real_estate");
?>